package testes;
import ui.Menu;

public class TesteMenu {

	public static void main(String[] args) {
		Menu m = new Menu();
		m.exibirMenu();
		

	}

}
